# my-reproducible manuscript

<!-- badges: start -->
<!-- badges: end -->

The goal of my-reproducible-manuscript is to ...

